<footer class="bg-dark p-3">
    @ 2023
</footer>
<?php /**PATH C:\xampp\htdocs\food-delivery-application\fooddeliveryapp\resources\views/include/footer.blade.php ENDPATH**/ ?>